package com.learnkafkastreams.domain;

public record HostInfoDTOWithKey(String host, int port, String key) {
}
